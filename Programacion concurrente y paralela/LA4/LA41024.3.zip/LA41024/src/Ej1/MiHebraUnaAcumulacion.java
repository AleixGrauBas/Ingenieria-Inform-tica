package Ej1;

public class MiHebraUnaAcumulacion extends Thread{
    int miId, numHebras;
    long numRectangulos;
    Acomula a;
    double baseRectangulo,suma;

    MiHebraUnaAcumulacion(int miId, int numHebras, long numRectangulos, Acomula a){
        this.miId=miId;
        this.numHebras=numHebras;
        this.numRectangulos=numRectangulos;
        this.a=a;
        baseRectangulo=1.0/((double)numRectangulos);
        suma=0.0;
    }
    public void run(){
        for (int i=miId;i<numRectangulos;i+=numHebras){
            double x=baseRectangulo*(((double) i)+0.5);
            suma+=f(x);
        }
        a.acomulaDato(suma);
    }
    static double f(double x){
        return (4.0/(1.0 + x*x));
    }
}
