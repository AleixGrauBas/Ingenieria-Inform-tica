package Ej1;

import java.util.concurrent.atomic.DoubleAdder;

public class EjemploNumeroPI {
    public static void main(String[] args) throws InterruptedException {
        long numRectangulos;
        double baseRectangulo,x,suma,pi;
        int numHebras;
        long t1,t2;
        double tSec,tPar;
        Acomula a;
        MiHebraMultAcumulaciones vt[];

       if(args.length!=2){
            System.out.println("ERROR: num de argumentos incorrecto");
            System.out.println("Uso: java programa <numHebras> <numRectángulos>");
            System.exit(-1);
        }
        try{
            numHebras=Integer.parseInt(args[0]);
            numRectangulos=Integer.parseInt(args[1]);
        }catch (NumberFormatException ex){
            numHebras=-1;
            numRectangulos=-1;
            System.out.println("ERROR: Numeros de entrada incorrectos");
            System.exit(-1);
        }
        System.out.println();
        System.out.println("Cálculo del número PI mediante integración ");

        //SECUENCIAL
        System.out.println();
        System.out.println("Comienzo del calculo secuencial");
        t1=System.nanoTime();
        baseRectangulo=1.0/((double)numRectangulos);
        suma=0.0;
        for(long i=0;i<numRectangulos;i++){
            x=baseRectangulo*(((double) i )+0.5);
            suma+=f(x);
        }
        pi=baseRectangulo*suma;
        t2=System.nanoTime();
        tSec=((double) (t2-t1))/1.0e9;
        System.out.println("Version secuencial. Numero PI: "+pi);
        System.out.println("Tiempo secuencial: "+tSec);

        //PARALELO distribución cíclica
        //múltiples acumulaciones por hebra

        System.out.println();
        System.out.println("Comienzo del calculo paralelo multiples acomulaciones");
        t1=System.nanoTime();

        a=new Acomula();
        MiHebraMultAcumulaciones[] vector=new MiHebraMultAcumulaciones[numHebras];

        for (int i=0;i<numHebras;i++){
            vector[i]= new MiHebraMultAcumulaciones(i,numHebras,numRectangulos,a);
            vector[i].start();
        }

       for (int i=0;i<numHebras;i++){
           vector[i].join();
       }

        pi=baseRectangulo*suma;
        t2=System.nanoTime();
        tPar=((double) (t2-t1))/1.0e9;
        System.out.println("Version paralela. Numero PI: "+pi);
        System.out.println("Tiempo paralelo: "+tPar);
        System.out.println("Incremento de la velocidad: "+tSec/tPar);

        //PARALELO distribución cíclica
        //una acumulacione por hebra

        System.out.println();
        System.out.println("Comienzo del calculo paralelo una acomulacion ");
        t1=System.nanoTime();

        a=new Acomula();
        MiHebraUnaAcumulacion[] vector2=new MiHebraUnaAcumulacion[numHebras];

        for (int i=0;i<numHebras;i++){
            vector2[i]= new MiHebraUnaAcumulacion(i,numHebras,numRectangulos,a);
            vector2[i].start();
        }

        for (int i=0;i<numHebras;i++){
            vector2[i].join();
        }

        pi=baseRectangulo*suma;
        t2=System.nanoTime();
        tPar=((double) (t2-t1))/1.0e9;
        System.out.println("Version paralela. Numero PI: "+pi);
        System.out.println("Tiempo paralelo: "+tPar);
        System.out.println("Incremento de la velocidad: "+tSec/tPar);


        //PARALELO distribución cíclica
        //múltiples acumulaciones por hebra (Atómica)

        System.out.println();
        System.out.println("Comienzo del calculo paralelo multiples acomulaciones (Atomic)");
        t1=System.nanoTime();
        DoubleAdder adder= new DoubleAdder();

        MiHebraMultAcumulacionAtomic[] vector3=new MiHebraMultAcumulacionAtomic[numHebras];

        for (int i=0;i<numHebras;i++){
            vector3[i]= new MiHebraMultAcumulacionAtomic(i,numHebras,numRectangulos,adder);
            vector3[i].start();
        }
        for (int i=0;i<numHebras;i++){
            vector3[i].join();
        }
        pi=baseRectangulo*adder.sum();
        t2=System.nanoTime();
        tPar=((double) (t2-t1))/1.0e9;
        System.out.println("Version paralela. Numero PI: "+pi);
        System.out.println("Tiempo paralelo: "+tPar);
        System.out.println("Incremento de la velocidad: "+tSec/tPar);

        //PARALELO distribución cíclica
        //una acumulacione por hebra (Atomic)
        System.out.println();
        System.out.println("Comienzo del calculo paralelo una acomulacion (Atomic)");
        t1=System.nanoTime();
        DoubleAdder adder2= new DoubleAdder();

        MiHebraUnaAcumulacionAtomic[] vector4=new MiHebraUnaAcumulacionAtomic[numHebras];

        for (int i=0;i<numHebras;i++){
            vector4[i]= new MiHebraUnaAcumulacionAtomic(i,numHebras,numRectangulos,adder2);
            vector4[i].start();
        }
        for (int i=0;i<numHebras;i++){
            vector4[i].join();
        }
        pi=baseRectangulo*adder2.sum();
        t2=System.nanoTime();
        tPar=((double) (t2-t1))/1.0e9;
        System.out.println("Version paralela. Numero PI: "+pi);
        System.out.println("Tiempo paralelo: "+tPar);
        System.out.println("Incremento de la velocidad: "+tSec/tPar);

    }

    static double f(double x){
        return (4.0/(1.0 + x*x));
    }
}
