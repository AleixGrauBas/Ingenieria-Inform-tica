package Ej1;

public class Acomula { //Objeto de la clase acomula para almacenar el resultado
    static double suma;
    Acomula(){
        suma=0.0;
    }
    void acomulaDato(double Dato){
        suma+=Dato;
    }
    double dameDato(){
        return suma;
    }
}
