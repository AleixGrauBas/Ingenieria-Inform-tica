package Ej2;

import javax.swing.*;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.atomic.AtomicBoolean;

import static Ej2.GUISecuenciaPrimos.*;

public class HebraAuxiliar extends Thread{
    AtomicBoolean sigue;
    HebraAuxiliar(AtomicBoolean sigue){
        this.sigue=sigue;
    }
    public void run() {

        try {
            SwingUtilities.invokeAndWait(new Runnable(){
                public void run(){
                    int i=0;
                    while(sigue.get()){
                        if(esPrimo(i)){

                            //txfMensajes Pero no lo podemos llamar desde aquí
                            

                        }
                    }
                }
            });
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }

    }
    }

