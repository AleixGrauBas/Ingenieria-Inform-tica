package Ej1;

import java.util.concurrent.atomic.DoubleAccumulator;
import java.util.concurrent.atomic.DoubleAdder;

public class MiHebraMultAcumulacionAtomic extends Thread{
    DoubleAdder adder;
    int miId, numHebras;
    long numRectangulos;

    double baseRectangulo;

    MiHebraMultAcumulacionAtomic(int miId, int numHebras, long numRectangulos, DoubleAdder a){
        this.miId=miId;
        this.numHebras=numHebras;
        this.numRectangulos=numRectangulos;
        this.adder=a;
        baseRectangulo=1.0/((double)numRectangulos);
    }
    public void run(){
        for (int i=miId;i<numRectangulos;i+=numHebras){
            double x=baseRectangulo*(((double) i)+0.5);
            adder.add(f(x));
        }
    }
    static double f(double x){
        return (4.0/(1.0 + x*x));
    }
}
