package Ej1;

import java.util.concurrent.atomic.DoubleAdder;

public class MiHebraUnaAcumulacionAtomic extends Thread{
    DoubleAdder adder;
    int miId, numHebras;
    long numRectangulos;

    double baseRectangulo,suma;

    MiHebraUnaAcumulacionAtomic(int miId, int numHebras, long numRectangulos, DoubleAdder a){
        this.miId=miId;
        this.numHebras=numHebras;
        this.numRectangulos=numRectangulos;
        this.adder=a;
        baseRectangulo=1.0/((double)numRectangulos);
        suma=0.0;
    }
    public void run(){
        for (int i=miId;i<numRectangulos;i+=numHebras){
            double x=baseRectangulo*(((double) i)+0.5);
            suma+=f(x);
        }
        adder.add(f(suma));
    }
    static double f(double x){
        return (4.0/(1.0 + x*x));
    }
}
