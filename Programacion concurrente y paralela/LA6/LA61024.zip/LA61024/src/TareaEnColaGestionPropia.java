public class TareaEnColaGestionPropia {
    boolean esVenenno;
    int codPueblo;
    public TareaEnColaGestionPropia(int codPueblo, boolean esVenenno){
        this.codPueblo=codPueblo;
        this.esVenenno=esVenenno;
    }
}
