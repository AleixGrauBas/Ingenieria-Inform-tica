import java.util.concurrent.ArrayBlockingQueue;

public class MiHebraParalela1 extends Thread{
    ArrayBlockingQueue<TareaEnColaGestionPropia> queue;
    PuebloMaximaMinima MaxMin;
    String fecha;

    public MiHebraParalela1(ArrayBlockingQueue<TareaEnColaGestionPropia> queue,String fecha,PuebloMaximaMinima maxmin){
        this.queue=queue;
        this.fecha=fecha;
        this.MaxMin=maxmin;

    }
    public void run(){

        try {
            TareaEnColaGestionPropia tarea=queue.take();
            while(!tarea.esVenenno){
                EjemploTemperaturaProvincia.ProcesaPueblo(fecha, tarea.codPueblo, MaxMin, false);
                tarea=queue.take();
            }

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }
}
