package Synchronized;

import Synchronized.CuentaIncrementosSyncronized;

public class MiHebraSyncrhonized extends Thread{
    int tope ;
    CuentaIncrementosSyncronized c;
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public MiHebraSyncrhonized ( int tope , CuentaIncrementosSyncronized c ) {
    this.tope = tope;
    this.c = c;
}
// −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
public void run () {
    for (int i=0;i<tope;i++) {
        c . incrementaNumIncrementos ( ) ;
        }
    }

}
