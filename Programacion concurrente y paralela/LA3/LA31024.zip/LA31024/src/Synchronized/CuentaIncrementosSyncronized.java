package Synchronized;

public class CuentaIncrementosSyncronized {
// ============================================================================
        int numIncrementos = 0 ;
// −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
       synchronized  void incrementaNumIncrementos ( ) {
            numIncrementos++;
        }
// −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
       synchronized int dameNumIncrementos ( ) {
            return ( numIncrementos ) ;
        }
    }

