package Volatile;

public class CuentaIncrementosVolatile {
    volatile int numIncrementos = 0 ;
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    void incrementaNumIncrementos ( ) {
        numIncrementos++;
    }
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    int dameNumIncrementos ( ) {
        return numIncrementos  ;
    }
}
