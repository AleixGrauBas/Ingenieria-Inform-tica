package Volatile;

import Original.CuentaIncrementos;

public class MiHebraVolatile extends Thread {
    int tope ;
    CuentaIncrementosVolatile c;
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public MiHebraVolatile(int tope , CuentaIncrementosVolatile c ) {
        this.tope = tope;
        this.c = c;
    }
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public void run () {
        for (int i=0;i<tope;i++) {
            c.incrementaNumIncrementos();
        }
    }

}
