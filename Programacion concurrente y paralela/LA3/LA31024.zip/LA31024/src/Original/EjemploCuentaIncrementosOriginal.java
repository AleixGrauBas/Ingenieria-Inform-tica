package Original;

public class EjemploCuentaIncrementosOriginal {
    public static void main(String[] args) {
        long t1,t2;
        double tt;
        int numHebras , tope ;

        numHebras=4;
        tope=1000000;


        System.out.println("numHebras: "+numHebras);
        System.out.println("tope: "+tope);
        System.out.println("Creando y arrancando "+numHebras+" hebras");
        t1=System.nanoTime();
        MiHebra v [ ] = new MiHebra [ numHebras ];
        CuentaIncrementos c=new CuentaIncrementos();

        for ( int i = 0 ; i < numHebras ; i++ ) {
            v [i]=new MiHebra(tope,c);
            v[i].start();
        }
        for ( int i = 0 ; i < numHebras ; i++ ) {
            try {
                v [i].join();
            } catch ( InterruptedException ex ) {
                ex.printStackTrace();
            }
        }
        t2 = System.nanoTime ( ) ;
        tt= (double)(t2-t1)/1.0e9;
        System.out.println("Total incrementos: "+c.dameNumIncrementos());
        System.out.println("Tiempo transcurrido en segundos: "+tt);
    }
}


