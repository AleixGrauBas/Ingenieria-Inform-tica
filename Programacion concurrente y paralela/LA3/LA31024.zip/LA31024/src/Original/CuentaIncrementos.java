package Original;

public class CuentaIncrementos {
    int numIncrementos = 0 ;
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    void incrementaNumIncrementos ( ) {
        numIncrementos++;
    }
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    int dameNumIncrementos ( ) {
        return numIncrementos  ;
    }
}
