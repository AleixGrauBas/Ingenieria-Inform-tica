package Original;

import java.util.concurrent.atomic.AtomicInteger;

public class MiHebra extends Thread {
    int tope ;
    CuentaIncrementos c;
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public MiHebra ( int tope , CuentaIncrementos c ) {
        this.tope = tope;
        this.c = c;
    }
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public void run () {
        for (int i=0;i<tope;i++) {
            c.incrementaNumIncrementos();
        }
    }

}
