package Atomic;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicClass {
    static AtomicInteger contadorAtomico;
    public AtomicClass(){
        contadorAtomico=new AtomicInteger(0);
    }
     void incrementaNumIncrementos ( ) {
        int cont=contadorAtomico.get()+1;
         contadorAtomico.set(cont);
    }
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
     int dameNumIncrementos ( ) {
       return contadorAtomico.get();
    }
}
