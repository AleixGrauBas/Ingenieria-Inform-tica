package Atomic;

import Atomic.MiHebraAtomic;

import java.util.concurrent.atomic.AtomicInteger;

public class EjemploCuentaIncrementosAtomic {
    public static void main(String[] args) {
        long t1,t2;
        double tt;
        int numHebras , tope ;

        numHebras=4;
        tope=1000000;
        AtomicInteger contador = new AtomicInteger(0);

        System.out.println("numHebras: "+numHebras);
        System.out.println("tope: "+tope);
        System.out.println("Creando y arrancando "+numHebras+" hebras");
        t1=System.nanoTime();
        MiHebraAtomic v [ ] = new MiHebraAtomic [ numHebras ];


        for ( int i = 0 ; i < numHebras ; i++ ) {
            v [i]=new MiHebraAtomic(tope,contador);
            v[i].start();
        }
        for ( int i = 0 ; i < numHebras ; i++ ) {
            try {
                v [i].join();
            } catch ( InterruptedException ex ) {
                ex.printStackTrace();
            }
        }

        t2 = System.nanoTime ( ) ;
        tt= (double)(t2-t1)/1.0e9;
        System.out.println("Total incrementos: "+contador);
        System.out.println("Tiempo transcurrido en segundos: "+tt);
    }
}


