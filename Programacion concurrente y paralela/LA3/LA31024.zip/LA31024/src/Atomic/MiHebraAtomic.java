package Atomic;

import java.util.concurrent.atomic.AtomicInteger;

public class MiHebraAtomic extends Thread{
    int tope ;
    AtomicInteger contador;
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public MiHebraAtomic ( int tope , AtomicInteger contador ) {
        this.tope = tope;
        this.contador = contador;
    }
    // −−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−−
    public void run () {
        for (int i=0;i<tope;i++) {
            int cont=contador.get()+1;
            contador.set(cont);
        }
    }
}

